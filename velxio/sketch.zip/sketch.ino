#include <WiFi.h>
#include <PubSubClient.h>


const char* ssid = "Wokwi-GUEST"; 
const char* password = "";

const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;


const char* topic = "mohsen/velxio/telemetry";

WiFiClient espClient;
PubSubClient client(espClient);


String state = "Shake"; 

float accX = 0;
float accY = 0;
float accZ = 9.81;

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}


void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");

    if (client.connect("ESP32_Velxio_Client")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 2 seconds");
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();


  if (state == "Idle") {
    accX = (random(-10, 10) / 100.0);
    accY = (random(-10, 10) / 100.0);
    accZ = 9.81 + (random(-10, 10) / 100.0);
    
  } else if (state == "Move") {
    float time_sec = millis() / 1000.0;
    accX = sin(time_sec * 3) * 3.0;
    accY = cos(time_sec * 3) * 3.0;
    accZ = 9.81 + sin(time_sec * 5) * 1.5;
    
  } else if (state == "Shake") {
    accX = (random(-300, 300) / 10.0);
    accY = (random(-300, 300) / 10.0);
    accZ = 9.81 + (random(-300, 300) / 10.0);
  }


  String payload = "{\"accX\":" + String(accX, 2) + 
                   ",\"accY\":" + String(accY, 2) + 
                   ",\"accZ\":" + String(accZ, 2) + 
                   ",\"state\":\"" + state + "\"}";


  client.publish(topic, payload.c_str());

  Serial.println(payload);

  delay(20); 
}